package p2;

/**
 * Deadlock Exception class
 * 
 * @author Jordi Linares
 *
 */
@SuppressWarnings("serial")
public class DeadlockException extends Exception {
	public DeadlockException() {
		super();
	}
}
